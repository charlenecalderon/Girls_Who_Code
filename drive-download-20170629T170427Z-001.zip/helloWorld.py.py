def firstfunction ():
    print("This is my first function")

def helloYou(name):
    print("Hello,",name)

#print("Happy Friday")
#firstfunction()

#helloYou("Jessica")

print("What is your name?)
name = input()
helloYou(name)
      
